#pragma once
#include <iostream>
enum button_state
{
    MOUSE_OUT = 0,
    MOUSE_OVER = 1,
    CLICKED = 2
};

enum state_state
{
    ALIVE = 0,
    DYING = 1
};